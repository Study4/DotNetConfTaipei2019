USE master;
GO
/*--ALTER DATABASE Work 
    SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
*/
GO
/*
DROP DATABASE IF EXISTS Work;
GO
CREATE DATABASE Work;
GO
*/
USE Work;
GO

-- create a biggish table:
DROP TABLE IF EXISTS dbo.NewTable;

SELECT TOP (2500000) s1.* INTO dbo.NewTable 
  FROM sys.all_columns AS s1
  CROSS JOIN sys.all_objects AS s2;
GO

-- start a "long-running" index create, then
-- quickly jump to other tab and pause it

CREATE CLUSTERED INDEX x 
  ON dbo.NewTable (object_id,column_id)
  WITH 
  (
    ONLINE = ON, RESUMABLE = ON, 
	MAX_DURATION = 10 MINUTES
  );

drop index x on NewTable
