use work
go
set showplan_all off;
set showplan_all on;
go
set statistics time off;
set statistics io off;
set statistics time on;
set statistics io on;
go
-- SQL 2019  �ϥΪ�����p�e�|���P
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_100'))
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_110'))
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_120'))
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_130'))
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_140'))
select count(distinct c2) from tbBig option(use hint('query_optimizer_compatibility_level_150'))



