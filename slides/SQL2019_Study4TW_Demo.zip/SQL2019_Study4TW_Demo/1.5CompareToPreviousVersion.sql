-- new database scoped configurations
SELECT id = l.configuration_id, l.name, COALESCE(r.name, '  *** NEW! ***'), l.value
FROM sys.database_scoped_configurations AS l -- CTP 3.2
LEFT OUTER JOIN 
[.].[master].sys.database_scoped_configurations AS r -- 2017
ON l.name = r.name; 

select * from sys.dm_exec_valid_use_hints order by 1

-- new use hints (I know the compatibility level hints are a special back-ported case)
SELECT l.name, 
  CASE WHEN r.name LIKE N'%COMPAT%' THEN '(In 2017 but backported)' 
  ELSE COALESCE(r.name, '  *** NEW! ***') END
FROM sys.dm_exec_valid_use_hints AS l -- CTP 3.2
LEFT OUTER JOIN 
[.].[master].sys.dm_exec_valid_use_hints AS r -- 2017
ON l.name = r.name; 

select * from sys.messages where language_id=1033

-- new error messages that arrive before features
SELECT message_id, text
FROM sys.messages AS m
WHERE language_id = 1033 
AND NOT EXISTS  
(
  SELECT 1 FROM [.].master.sys.messages
  WHERE message_id = m.message_id
);

