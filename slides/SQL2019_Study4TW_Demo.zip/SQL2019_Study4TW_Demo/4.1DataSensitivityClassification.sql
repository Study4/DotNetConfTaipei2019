USE master;
GO
/*
  ALTER DATABASE Work 
  SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
DROP DATABASE IF EXISTS Work;
GO
CREATE DATABASE Work;
GO
*/
USE Work;
GO

DROP TABLE IF EXISTS dbo.Contractors;
GO

CREATE TABLE dbo.Contractors
(
  ContractorID int,
  FirstName    sysname, 
  LastName     sysname, 
  SSN          char(9), 
  HourlyRate   decimal(6,2)
);

ADD SENSITIVITY CLASSIFICATION 
  TO dbo.Contractors.FirstName, 
     dbo.Contractors.LastName   -- two columns!
WITH (LABEL = 'Confidential - GDPR', INFORMATION_TYPE = 'Personal Info');

ADD SENSITIVITY CLASSIFICATION TO dbo.Contractors.SSN
WITH (LABEL = 'Highly Confidential', INFORMATION_TYPE = 'National ID');

ADD SENSITIVITY CLASSIFICATION TO dbo.Contractors.HourlyRate
WITH (LABEL = 'Lawsuit Waiting to Happen', INFORMATION_TYPE = 'Financial');

SELECT major_id, minor_id, label, information_type
  FROM sys.sensitivity_classifications 
  WHERE major_id = OBJECT_ID(N'dbo.Contractors');
GO

USE [master];
GO

CREATE SERVER AUDIT [Audit-AGroupByDemo]
TO FILE 
(
  FILEPATH = N'c:\temp\',
  MAXSIZE = 0 MB,
  MAX_ROLLOVER_FILES = 2147483647,
  RESERVE_DISK_SPACE = OFF
)
WITH
(
  QUEUE_DELAY = 1000,
  ON_FAILURE = CONTINUE
);
GO

ALTER SERVER AUDIT [Audit-AGroupByDemo] WITH (STATE = ON);
GO

USE Work;
GO

CREATE DATABASE AUDIT SPECIFICATION [ObjectAccessed]
  FOR SERVER AUDIT [Audit-AGroupByDemo]
  ADD (SCHEMA_OBJECT_ACCESS_GROUP);
GO

ALTER DATABASE AUDIT SPECIFICATION [ObjectAccessed] WITH (STATE = ON);
GO

SELECT * FROM dbo.Contractors;
GO


SELECT 
    event_time, 
    [host_name], 
    [server_principal_id],
    [object] = [database_name] + '.' + [schema_name] + '.' + [object_name],
    [statement],
    gdpr_label = TRY_CONVERT(xml, data_sensitivity_information)
  FROM sys.fn_get_audit_file(N'c:\temp\Audit-AGroupByDemo*.sqlaudit',default,default)
  WHERE action_id = N'SL'
  order by event_time desc;

-- clean up:
ALTER DATABASE AUDIT SPECIFICATION [ObjectAccessed] WITH (STATE = OFF);
GO
DROP DATABASE AUDIT SPECIFICATION [ObjectAccessed];
GO
DROP TABLE dbo.Contractors;
GO
USE [master];
GO
ALTER SERVER AUDIT [Audit-AGroupByDemo] WITH (STATE = OFF);
GO
DROP SERVER AUDIT [Audit-AGroupByDemo];
GO
ALTER DATABASE Work SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
DROP DATABASE IF EXISTS Work;
GO
