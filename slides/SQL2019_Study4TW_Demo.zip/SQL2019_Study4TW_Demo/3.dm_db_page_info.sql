use Work
--https://techcommunity.microsoft.com/t5/SQL-Server/SQL-Server-2019-CTP-2-0-New-Features-8211-Introducing-the-Page/ba-p/386009
SELECT 
*
FROM sys.dm_db_database_page_allocations(DB_ID(),OBJECT_ID(N'dbo.tbBig'), NULL, NULL, N'DETAILED')
WHERE is_allocated = 1;	

select * from sys.dm_db_page_info(db_id(),1,288, N'DETAILED')


SELECT page_info.* 
FROM sys.dm_exec_requests AS d 
outer APPLY sys.fn_PageResCracker(d.page_resource) AS r 
outer APPLY sys.dm_db_page_info(r.db_id, r.file_id, r.page_id, 1) AS page_info 



