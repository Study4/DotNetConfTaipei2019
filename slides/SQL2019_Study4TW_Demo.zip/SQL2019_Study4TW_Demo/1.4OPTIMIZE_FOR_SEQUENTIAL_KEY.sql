use work
go

drop table if exists tbBig2
--���G page �V�p�A���U�V��...
create table tbBig2(pk bigint identity primary key --)
,
c2 uniqueidentifier default(newsequentialid()),
c3 datetimeoffset(7) default(sysdatetimeoffset()),
c4 float default(rand()),
c5 nvarchar(100) default(N'hello sql 2019'),
c6 numeric(38) default(rand()*power(10,9)),
c7 int default(datepart(second,getdate())))

go

dbcc sqlperf('sys.dm_os_wait_stats',clear)


--"C:\Program Files\Microsoft Corporation\RMLUtils\ostress" -S.\sql2019 -dWork -Q"insert tbBig2 default values" -mstress -n100 -r10000 -q

/*
OSTRESS exiting normally, elapsed time: 00:01:07.849
SOS_WORK_DISPATCHER	1001098	26095183	1883395	126281
PAGELATCH_EX	1364597	1864465	16	43501
WRITELOG	1000235	1774166	47	203573
PAGELATCH_SH	702214	772310	15	41605
*/
/*
SOS_WORK_DISPATCHER	1001014	52847722	616315	128638
WRITELOG	1000149	1588940	49	208076
PAGELATCH_EX	1039961	1536073	21	37248

*/
select * from sys.dm_os_wait_stats order by wait_time_ms desc
go

drop table if exists tbBig3

create table tbBig3(pk bigint identity primary key with( OPTIMIZE_FOR_SEQUENTIAL_KEY=on) --)
,
c2 uniqueidentifier default(newsequentialid()),
c3 datetimeoffset(7) default(sysdatetimeoffset()),
c4 float default(rand()),
c5 nvarchar(100) default(N'hello sql 2019'),
c6 numeric(38) default(rand()*power(10,9)),
c7 int default(datepart(second,getdate())))
go

dbcc sqlperf('sys.dm_os_wait_stats',clear)

--"C:\Program Files\Microsoft Corporation\RMLUtils\ostress" -S.\sql2019 -dWork -Q"insert tbBig3 default values" -mstress -n100 -r10000 -q

/*
OSTRESS exiting normally, elapsed time: 00:01:07.888
SOS_WORK_DISPATCHER	1001176	15269311	1850905	109051
BTREE_INSERT_FLOW_CONTROL	942144	2131518	489	33563
WRITELOG	1000523	1614033	200	168935
PAGELATCH_EX	1194516	466725	246	41795
*/
select * from sys.dm_os_wait_stats order by wait_time_ms desc

/*
tbBig2	1765581328	2066	0x988F00000100	1	0x759100000100	67	1	1	21367	21473	21469
tbBig3	1893581784	2066	0x100301000100	1	0xED0401000100	67	1	1	24251	24369	24366
*/
select object_name(id),* from sysindexes where id in(object_id('tbBig2'),object_id('tbBig3'))
select * from sys.dm_db_index_physical_stats(db_id(),object_id('tbBig2'),1,null,null)
select * from sys.dm_db_index_physical_stats(db_id(),object_id('tbBig3'),1,null,null)

